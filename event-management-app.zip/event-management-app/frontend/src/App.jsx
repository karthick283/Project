import { useEffect, useState } from "react";
import "./EventsTable.css";

export default function EventsTable() {
  const [data, setData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [viewItem, setViewItem] = useState(null);
  const [editItem, setEditItem] = useState(null);
  const [editFormData, setEditFormData] = useState({
    id: "",
    batch_name: "",
    branch: "",
    from_date: "",
    to_date: "",
    time_slot: "",
    batch_days: [],
    batches_location: "",
    batch_status: "",
    instructor: "",
    additional_instructor: "",
    resources: "",
    min_students: "",
    max_students: "",
    remarks: "",
    class_details: "",
    levels: "",
    class_type: "",
    schedule_type: "",
  });

  // Helper to format date strings as YYYY-MM-DD for <input type="date" />
  function formatDateForInput(dateStr) {
    if (!dateStr) return "";
    const d = new Date(dateStr);
    if (isNaN(d)) return "";
    return d.toISOString().split("T")[0];
  }

  // Safely parse batch_days as array
  function parseBatchDays(days) {
    if (!days) return [];
    if (Array.isArray(days)) return days;
    if (typeof days === "string") {
      return days.split(",").map((d) => d.trim());
    }
    return [];
  }

  useEffect(() => {
    fetch("http://localhost:3000/api/data")
      .then((res) => {
        if (!res.ok) throw new Error(`Failed to fetch: ${res.statusText}`);
        return res.json();
      })
      .then((json) => {
        setData(json);
        setFilteredData(json);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, []);

  function handleSearch(e) {
    const term = e.target.value.toLowerCase();
    setSearchTerm(term);

    if (!term) {
      setFilteredData(data);
      return;
    }

    const filtered = data.filter(
      (item) =>
        (item.batch_name && item.batch_name.toLowerCase().includes(term)) ||
        (item.branch && item.branch.toLowerCase().includes(term)) ||
        (item.from_date && formatDateForInput(item.from_date).includes(term))
    );
    setFilteredData(filtered);
  }

  function handleDelete(item) {
    if (window.confirm(`Are you sure you want to delete batch "${item.batch_name}"?`)) {
      fetch(`http://localhost:3000/api/data/${item.id}`, {
        method: "DELETE",
      })
        .then((res) => {
          if (!res.ok) throw new Error(`Failed to delete: ${res.statusText}`);
          setData((prev) => prev.filter((d) => d.id !== item.id));
          setFilteredData((prev) => prev.filter((d) => d.id !== item.id));
        })
        .catch((err) => {
          setError(err.message);
        });
    }
  }

  function handleEditClick(item) {
    setEditItem(item);
    setEditFormData({
      id: item.id || "",
      batch_name: item.batch_name || "",
      branch: item.branch || "",
      from_date: formatDateForInput(item.from_date),
      to_date: formatDateForInput(item.to_date),
      time_slot: item.time_slot || "",
      batch_days: parseBatchDays(item.batch_days),
      batches_location: item.batch_location || "",
      batch_status: item.batch_status || "",
      instructor: item.instructor || "",
      additional_instructor: item.additional_instructor || "",
      resources: item.resources || "",
      min_students: item.min_students || "",
      max_students: item.max_students || "",
      remarks: item.remarks || "",
      class_details: item.class_details || "",
      levels: item.levels || "",
      class_type: item.class_type || "",
      schedule_type: item.schedule_type || "",
    });
  }

  function handleEditChange(e) {
    const { name, value, type, checked } = e.target;
    if (type === "checkbox") {
      setEditFormData((prev) => ({
        ...prev,
        batch_days: checked
          ? [...prev.batch_days, value]
          : prev.batch_days.filter((day) => day !== value),
      }));
    } else {
      setEditFormData((prev) => ({
        ...prev,
        [name]: value,
      }));
    }
  }

  async function handleSave() {
    if (!editFormData.id) {
      setError("Cannot save: Batch ID is missing");
      return;
    }

    const updatedItem = { ...editItem, ...editFormData };
    try {
      const response = await fetch(`http://localhost:3000/api/data/${editFormData.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(updatedItem),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Failed to update the batch (Status: ${response.status})`);
      }

      const updatedData = [...data];
      const originalIndex = data.findIndex((d) => d.id === editItem.id);
      if (originalIndex !== -1) {
        updatedData[originalIndex] = updatedItem;
      }
      setData(updatedData);

      const updatedFiltered = [...filteredData];
      const filteredIndex = filteredData.findIndex((d) => d.id === editItem.id);
      if (filteredIndex !== -1) {
        updatedFiltered[filteredIndex] = updatedItem;
      }
      setFilteredData(updatedFiltered);

      setEditItem(null);
      setEditFormData({
        id: "",
        batch_name: "",
        branch: "",
        from_date: "",
        to_date: "",
        time_slot: "",
        batch_days: [],
        batch_location: "",
        batch_status: "",
        instructor: "",
        additional_instructor: "",
        resources: "",
        min_students: "",
        max_students: "",
        remarks: "",
        class_details: "",
        levels: "",
        class_type: "",
        schedule_type: "",
      });
    } catch (err) {
      setError(err.message);
      console.error("Update error:", err);
    }
  }

  function handleCancel() {
    setEditItem(null);
    setEditFormData({
      id: "",
      batch_name: "",
      branch: "",
      from_date: "",
      to_date: "",
      time_slot: "",
      batch_days: [],
      batch_location: "",
      batch_status: "",
      instructor: "",
      additional_instructor: "",
      resources: "",
      min_students: "",
      max_students: "",
      remarks: "",
      class_details: "",
      levels: "",
      class_type: "",
      schedule_type: "",
    });
  }

  if (loading) return <p className="no-data">Loading data...</p>;
  if (error) return <p className="no-data" style={{ color: "red" }}>Error: {error}</p>;

  return (
    <div className="container">
      <div className="search-bar">
        <input
          type="text"
          placeholder="Search events..."
          value={searchTerm}
          onChange={handleSearch}
          className="search-input"
        />
      </div>

      <table>
        <thead>
          <tr>
            <th>Batch Name</th>
            <th>Branch</th>
            <th>Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredData.length === 0 ? (
            <tr>
              <td colSpan="4" className="no-data">
                No events found
              </td>
            </tr>
          ) : (
            filteredData.map((item, idx) => (
              <tr key={item.id || idx}>
                <td>{item.batch_name}</td>
                <td>{item.branch}</td>
                <td>{item.from_date ? formatDateForInput(item.from_date) : ""}</td>
                <td>
                  <button className="view-btn" onClick={() => setViewItem(item)}>
                    View
                  </button>
                  <button className="edit-btn" onClick={() => handleEditClick(item)}>
                    Edit
                  </button>
                  <button className="delete-btn" onClick={() => handleDelete(item)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>

      {viewItem && (
        <div className="modal-overlay" onClick={() => setViewItem(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <h2>Event Details</h2>
            <table className="details-horizontal-table">
              <thead>
                <tr>
                  {Object.keys(viewItem).map((key) => (
                    <th key={key}>{key.replace(/_/g, " ").toUpperCase()}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <tr>
                  {Object.values(viewItem).map((value, idx) => (
                    <td key={idx}>{String(value)}</td>
                  ))}
                </tr>
              </tbody>
            </table>
            <button className="close-btn" onClick={() => setViewItem(null)}>
              Close
            </button>
          </div>
        </div>
      )}

      {editItem && (
        <div className="modal-overlay" onClick={handleCancel}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <h2>Edit Event</h2>
            <form className="edit-form">
              <div className="form-row">
                <label>
                  Batch Name
                  <input
                    name="batch_name"
                    type="text"
                    value={editFormData.batch_name}
                    onChange={handleEditChange}
                  />
                </label>
                <label>
                  Branch
                  <select
                    name="branch"
                    value={editFormData.branch}
                    onChange={handleEditChange}
                  >
                    <option value="Adyar">Adyar</option>
                    <option value="Guindy">Guindy</option>
                    <option value="Anna Nagar">Anna Nagar</option>
                    {/* Add more branches as needed */}
                  </select>
                </label>
                <label>
                  Levels
                  <select
                    name="levels"
                    value={editFormData.levels}
                    onChange={handleEditChange}
                  >
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Advanced">Advanced</option>
                  </select>
                </label>
                <label>
                  Class Type
                  <select
                    name="class_type"
                    value={editFormData.class_type}
                    onChange={handleEditChange}
                  >
                    <option value="Online">Regular</option>
                    <option value="Offline">Offline</option>
                    <option value="hybrid">Hybrid</option>
                  </select>
                </label>
              </div>

              <div className="form-row">
                <label>
                  Class Details
                  <input
                    name="class_details"
                    type="text"
                    value={editFormData.class_details}
                    onChange={handleEditChange}
                  />
                </label>
                <label>
                  Schedule Type
                  <select
                    name="schedule_type"
                    value={editFormData.schedule_type}
                    onChange={handleEditChange}
                  >
                    <option value="Weekly">Weekly</option>
                    <option value="Bi-weekly">Bi-weekly</option>
                    <option value="Weekend Only"> Weekend Only</option>
                  </select>
                </label>
                <label>
                  From Date
                  <input
                    name="from_date"
                    type="date"
                    value={editFormData.from_date}
                    onChange={handleEditChange}
                  />
                </label>
                <label>
                  To Date
                  <input
                    name="to_date"
                    type="date"
                    value={editFormData.to_date}
                    onChange={handleEditChange}
                  />
                </label>
              </div>

              <div className="form-row">
                <label>
                  Time Slot
                  <select
                    name="time_slot"
                    value={editFormData.time_slot}
                    onChange={handleEditChange}
                  >
                    <option value="9:00 AM - 11:00 AM">9:00 AM - 11:00 AM</option>
                    <option value="10:30 AM - 12:30 PM">10:30 AM - 12:30 PM</option>
                    <option value="2:00 PM - 4:00 PM">2:00 PM - 4:00 PM</option>
                    {/* Add more time slots as needed */}
                  </select>
                </label>
                <fieldset>
                  <legend>Batch Days</legend>
                  <div className="checkbox-group">
                    {["M", "T", "W", "Th", "F", "Sa", "Su"].map((day) => (
                      <label key={day}>
                        <input
                          type="checkbox"
                          name="batch_days"
                          value={day}
                          checked={editFormData.batch_days.includes(day)}
                          onChange={handleEditChange}
                        />
                        {day}
                      </label>
                    ))}
                  </div>
                </fieldset>
                <label>
                  Batch Location
                  <select
                    name="batch_location"
                    value={editFormData.batch_location}
                    onChange={handleEditChange}
                  >
                    <option value="Room 101">Room 101</option>
                    <option value="Room 202">Room 202</option>
                    <option value="Auditorim">Auditorim</option>
                  </select>
                </label>
              </div>

              <div className="form-row">
                <label>
                  Batch Status
                  <select
                    name="batch_status"
                    value={editFormData.batch_status}
                    onChange={handleEditChange}
                  >
                    <option value="Flexible">Flexible</option>
                    <option value="Moderate">Moderate</option>
                    <option value="Strict">Strict</option>
                  </select>
                </label>
                <label>
                  Instructor
                  <select
                    name="instructor"
                    value={editFormData.instructor}
                    onChange={handleEditChange}
                  >
                    <option value="John Doe">John Doe</option>
                    <option value="Bob Smith">Bob Smith</option>
                  </select>
                </label>
                <label>
                  Additional Instructor
                  <select
                    name="additional_instructor"
                    value={editFormData.additional_instructor}
                    onChange={handleEditChange}
                  >
                    <option value="">None</option>
                    <option value="Alice Johnson">Alice Johnson</option>
                    <option value="Bob Smith">Bob Smith</option>
                  </select>
                </label>
                <label>
                  Resources
                  <select
                    name="resources"
                    value={editFormData.resources}
                    onChange={handleEditChange}
                  >
                    <option value="Whiteboards">Whiteboards</option>
                    <option value="Projectors">Projectors</option>
                  </select>
                </label>
              </div>

              <div className="form-row">
                <label>
                  Min Students
                  <input
                    name="min_students"
                    type="number"
                    value={editFormData.min_students}
                    onChange={handleEditChange}
                  />
                </label>
                <label>
                  Max Students
                  <input
                    name="max_students"
                    type="number"
                    value={editFormData.max_students}
                    onChange={handleEditChange}
                  />
                </label>
                <label>
                  Remarks
                  <textarea
                    name="remarks"
                    value={editFormData.remarks}
                    onChange={handleEditChange}
                  />
                </label>
              </div>

              <div className="form-buttons">
                <button type="button" onClick={handleSave}>
                  Save
                </button>
                <button type="button" onClick={handleCancel}>
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}