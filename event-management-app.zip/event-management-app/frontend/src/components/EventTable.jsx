import { useState } from 'react';
import ViewModal from './ViewModal';
import EditModal from './EditModal';
import DeleteModal from './DeleteModal';

function EventTable({ events, fetchEvents }) {
  const [viewEvent, setViewEvent] = useState(null);
  const [editEvent, setEditEvent] = useState(null);
  const [deleteEvent, setDeleteEvent] = useState(null);

  return (
    <>
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white border border-gray-200">
          <thead className="bg-gray-100">
            <tr>
              <th className="px-4 py-2 text-left">
                <input type="checkbox" />
              </th>
              <th className="px-4 py-2 text-left">Name</th>
              <th className="px-4 py-2 text-left">Branch</th>
              <th className="px-4 py-2 text-left">Date</th>
              <th className="px-4 py-2 text-left">Actions</th>
            </tr>
          </thead>
          <tbody>
            {events.map(event => (
              <tr key={event.id} className="border-t">
                <td className="px-4 py-2">
                  <input type="checkbox" />
                </td>
                <td className="px-4 py-2">{event.batch_name}</td>
                <ted className="px-4 py-2">{event.branch}</ted>
                <td className="px-4 py-2">{event.from_date}</td>
                <td className="px-4 py-2 space-x-2">
                  <button
                    onClick={() => setViewEvent(event)}
                    className="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600"
                  >
                    View
                  </button>
                  <button
                    onClick={() => setEditEvent(event)}
                    className="px-3 py-1 bg-green-500 text-white rounded hover:bg-green-600"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => setDeleteEvent(event)}
                    className="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {viewEvent && (
        <ViewModal event={viewEvent} onClose={() => setViewEvent(null)} />
      )}
      {editEvent && (
        <EditModal
          event={editEvent}
          onClose={() => setEditEvent(null)}
          fetchEvents={fetchEvents}
        />
      )}
      {deleteEvent && (
        <DeleteModal
          event={deleteEvent}
          onClose={() => setDeleteEvent(null)}
          fetchEvents={fetchEvents}
        />
      )}
    </>
  );
}

export default EventTable;