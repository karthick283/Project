function ViewModal({ event, onClose }) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-white p-6 rounded-lg shadow-lg w-96">
        <h2 className="text-xl font-bold mb-4">Event Details</h2>
        <p><strong>Name:</strong> {event.batch_name}</p>
        <p><strong>Branch:</strong> {event.branch}</p>
        <p><strong>Date:</strong> {event.from_date}</p>
        <button
          onClick={onClose}
          className="mt-4 px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600"
        >
          Close
        </button>
      </div>
    </div>
  );
}

export default ViewModal;