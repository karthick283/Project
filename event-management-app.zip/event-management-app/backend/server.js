const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'postgres',
  password: '12345678',
  port: 5432,
});

// Fetch all batches
app.get('/api/data', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM events');
    res.json(result.rows);
  } catch (err) {
    console.error(err.stack);
    res.status(500).json({ error: 'Failed to fetch data' });
  }
});

// Update a batch
app.put('/api/data/:id', async (req, res) => {
  const { id } = req.params;
  const {
    batch_name,
    branch,
    from_date,
    to_date,
    time_slot,
    batch_days,
    batch_location,
    batch_status,
    instructor,
    additional_instructor,
    resources,
    min_students,
    max_students,
    remarks,
    class_details,
    levels,
    class_type,
    schedule_type,
  } = req.body;

  try {
    const result = await pool.query(
      `UPDATE events SET
        batch_name = $1,
        branch = $2,
        from_date = $3,
        to_date = $4,
        time_slot = $5,
        batch_days = $6,
        batch_location = $7,
        batch_status = $8,
        instructor = $9,
        additional_instructor = $10,
        resources = $11,
        min_students = $12,
        max_students = $13,
        remarks = $14,
        class_details = $15,
        levels = $16,
        class_type = $17,
        schedule_type = $18
      WHERE id = $19
      RETURNING *`,
      [
        batch_name,
        branch,
        from_date,
        to_date,
        time_slot,
        batch_days,
        batches_location,
        batch_status,
        instructor,
        additional_instructor,
        resources,
        min_students,
        max_students,
        remarks,
        class_details,
        levels,
        class_type,
        schedule_type,
        id,
      ]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Batch not found' });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error(err.stack);
    res.status(500).json({ error: 'Failed to update batch' });
  }
});

// Delete a batch
app.delete('/api/data/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query('DELETE FROM events WHERE id = $1 RETURNING *', [id]);
    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Batch not found' });
    }
    res.json({ message: 'Batch deleted successfully' });
  } catch (err) {
    console.error(err.stack);
    res.status(500).json({ error: 'Failed to delete batch' });
  }
});

app.listen(3000, () => {
  console.log('Server running on port 3000');
});