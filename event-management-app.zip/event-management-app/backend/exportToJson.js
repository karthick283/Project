const { Pool } = require('pg');
const fs = require('fs');

// PostgreSQL connection config
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'postgres',
  password: '12345678',
  port: 5432,
});

async function exportData() {
  try {
    const result = await pool.query('SELECT * FROM batches');
    const rawData = result.rows;

    // Format date fields to 'YYYY-MM-DD'
    const formattedData = rawData.map(row => ({
      ...row,
      from_date: row.from_date ? new Date(row.from_date).toISOString().split('T')[0] : null,
      to_date: row.to_date ? new Date(row.to_date).toISOString().split('T')[0] : null,
    }));

    fs.writeFileSync('data.json', JSON.stringify(formattedData, null, 2));

    console.log('✅ Data exported to data.json successfully');
    pool.end();
  } catch (err) {
    console.error('❌ Error exporting data:', err);
  }
}

exportData();

